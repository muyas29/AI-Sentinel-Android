# AI Sentinel Android

This is an AI-powered security app for Android.

## Features:
- AI-based system monitoring
- Vault encryption
- Adaptive UI

### How to Build:
1. Clone this repository.
2. Open it in Android Studio.
3. Run `./gradlew assembleDebug` to build the APK.

### GitHub Actions:
This repo is set up to build APK automatically with GitHub Actions.
